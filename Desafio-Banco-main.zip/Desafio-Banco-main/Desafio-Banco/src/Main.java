public class Main {

    public static void main(String[] args) {
        Cliente ana = new Cliente();
        ana.setNome("Ana Beatriz");

        Conta cc = new ContaCorrente(ana);
        Conta cp = new ContaPoupanca(ana);

        cc.depositar(1000);
        cc.sacar(100);
        cc.transferir(100, cp);
        cp.depositar(200);
        
        cc.imprimirExtrato();
        cp.imprimirExtrato();
    }
}
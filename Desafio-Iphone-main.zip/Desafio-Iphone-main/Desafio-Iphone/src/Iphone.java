package src;
public class iPhone implements ReprodutorMusical, AparelhoTelefonico, NavegadorInternet {


    @Override
    public void ligar(String numero) {
        //Implementação aqui
        System.out.println("Ligando...");
    }

    @Override
    public void atender(String numero) {
        //Implementação aqui
        System.out.println("Atendendo chamada");
    }

    @Override
    public void iniciarCorreioVoz(String mensagem, String destinatario) {
        //Implementação aqui
        System.out.println("Iniciando Correio de voz");
    }

    @Override
    public void exibirPagina(String url) {
        //Implementação aqui
        System.out.println("Exibindo página " + url);
    }

    @Override
    public void adicionarNovaAba(String url) {
        //Implementação aqui
        System.out.println("Nova aba adicionada");

    }

    @Override
    public void atualizarPagina() {
        //Implementação aqui
        System.out.println("Página atualizada");

    }

    @Override
    public void tocar() {
        //Implementação aqui
        System.out.println("iPhone está tocando");

    }

    @Override
    public void pausar() {
        //Implementação aqui
        System.out.println("iPhone está pausando");
    }

    @Override
    public void selecionarMusica() {
        //Implementação aqui
        System.out.println("iPhone está selecionando música");
    }
}
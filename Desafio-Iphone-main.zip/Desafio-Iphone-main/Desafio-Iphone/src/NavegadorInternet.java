package src;

public interface NavegadorInternet {
    public void exibirPagina(String url);
    public void adicionarNovaAba(String url);
    public void atualizarPagina();
}